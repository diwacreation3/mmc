<?php session_start(); ?>
<html>
<head>
<!--
Author: Diwakar-Phuyal
Website: www.codingidenp.cf
profile: www.diwakar-phuyal.cf

-->
    <title>Homepage</title>
    <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div class="content">
    <div id="header">
        Welcome to Fire-Ice Testing Site
    </div>
    <?php
    if(isset($_SESSION['valid'])) {			
        include("connection.php");					
        $result = mysqli_query($mysqli, "SELECT * FROM login");
    ?>				
        Welcome <?php echo $_SESSION['name'] ?> ! <br>  <br>  <a class="a" href='view.php'>View and Add client</a><br><br><br>
        
        <a class="a"href='logout.php'>Logout</a><br/>
        <br><br><br>
    <?php	
    } else {
        echo "You must be logged in to view this page.<br/><br/>";
        echo " <button><a href='login.php'>Login</a></button> | <button><a href='register.php'>Register</a></button>";
    }
    ?>
    <div id="footer">
        Created by <a href="http://diwakar-phuyal.cf" title="Diwakar Phuyal">Diwakar Phuyal<br>
    For Fire-Ice</a>
    </div>
    </div>
<style>
    .content{
        text-align: center;
    }
    #header{
        background-color: #5ca1e1;
        color: #fff;
        padding: 15px;
        border-radius: 30% 30% 15px 15px;
    }
    #footer{
        background-color: #5ca1e1;
        color: #fff;
        padding: 15px;
        border-radius: 15px 15px  30% 30% ;
    }
    button{
        background-color: #5ca1e1;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 25px;
    }
    button a{
        text-decoration: none;
        color: white;
    }
    button:hover{
        background-color: #ccc;
    }
    .a{
        height: 100vh;
        width: 50px;
        padding: 8px;
        background: royalblue;
        color: #fff;
        text-decoration: none;
        margin: -10px;
        font-size: 18px;
       border-radius: 25px;
       
        
    }
    .a:hover{
        background: limegreen;
        transition: 1s;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
</style>
</body> 
</html>
