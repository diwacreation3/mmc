<?php
$dbhost ='localhost';
$dbname ='test0'; 
$dbuser ='root';    // username for database    
$dbpass ='';    // password for database    


$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

?>