<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add Data</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$name = $_POST['name'];
	$user = $_POST['user'];
	$pass = $_POST['pass'];
    $router= $_POST['router'];
    $price = $_POST['price'];
    $address = $_POST['address'];
    $comment = $_POST['comment'];
	$loginId = $_SESSION['id'];
		
	// checking empty fields
	if(empty($name) || empty($user) || empty($pass) || empty($router) || empty($price) || empty($address) || empty($comment)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($user)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($pass)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
        if(empty($router)) {
            echo "<font color='red'>Router field is empty.</font><br/>";
        }
        if(empty($price)) {
            echo "<font color='red'>Price field is empty.</font><br/>";
        }
        if(empty($address)) {
            echo "<font color='red'>Address field is empty.</font><br/>";
        }
        if(empty($comment)){
            echo "<font color='red'>Address field is empty.</font><br/>";
        }

		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO users(name, user, pass, router,price,address,comment, login_id) VALUES('$name','$user','$pass','$router','$price','$address','$comment' ,'$loginId')");
		
		//display success message
		echo "<font color='green'>Data added successfully<br/><br/>.";
		echo "<br/><a class='home' href='view.php'>View Result</a>";
	}
}
?>
</body>
</html>
