<?php session_start(); ?>
<html>
<head>
	<title>Homepage-WebSurfer</title>
    <!--
Author: Diwakar-Phuyal
Website: www.codingidenp.cf
profile: www.diwakar-phuyal.cf

-->
	
</head>

<body>
	<div id="header">
		Welcome to Websurfer Client portal...
	</div>
	<?php
	if(isset($_SESSION['valid'])) {			
		include("connection.php");					
		$result = mysqli_query($mysqli, "SELECT * FROM login");
	?>
				
		Welcome <?php echo $_SESSION['name'] ?> ! <a href='logout.php'>Logout</a><br/>
		<br/>
		<a class="view"href='view.php'>View and Add Products</a>
		<br/><br/>
	<?php	
	} else {
		echo "You must be logged in to view this page.<br/><br/>";
		echo "<a class='home' href='login.php'>Login</a>  <a class='home' href='register.php'>Register</a>";
	}
	?>
    <br><br>
	<div id="footer">
		Developed by Diwakar Phuyal <br>&copy;2022 Websurfer
	</div>
    <style>
        *{
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            font-size: auto;
        }
        #header{
            background: #003361;
            color: white;
            text-align: auto;
            padding: 20px;
            width:auto;
            border-radius: 10px 10px 0px 0px;
        }
        #footer{
            background: #003361;
            color: white;
            
            text-align: auto;
            padding: 20px;
            width:auto;
            border-radius: 0px 0px 10px 10px;
        }
        .home {
    text-decoration: none;
    color: white;
    background-color: #4CAF50;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #4CAF50;
}

.home:hover {
    background-color: #008CBA;
    color: white;
}

        .view{
            text-align: center;
            padding: 20px;
            border-radius: 10px 10px 0px 0px;
            text-decoration: none;
        }
        @media screen and (max-width: 600px){
            body{
                font-size:auto;
            }
            #header{
                text-align: center;
                font-size: 20px;

            }
            .view{
                text-align: center;
                font-size: 20px;
            }
        }

    </style>
</body>
</html>
