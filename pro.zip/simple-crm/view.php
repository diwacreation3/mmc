<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connection.php");

//fetching data in descending order (lastest entry first)
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE login_id=".$_SESSION['id']." ORDER BY id ASC");
?>

<html>
<head>
	<title>Homepage</title>
   
</head>

<body>
	<a class="home" href="index.php">Home</a>  <a class="home" href="add.html">Add New Data</a>  <a class="home" href="logout.php">Logout</a>
	<br/><br/>
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>
<div class="search-box">
        <input type="text" autocomplete="off" placeholder="Search users..." />
        <div class="result"></div>
    </div>
    <br><br>
	<table class="table">
		<tr class ="tr">
            <td>ID</td>
			<td>Name</td>
			<td>UserName</td>
			<td>Password</td>
            <td>Router(model)</td>
            <td>Price (RS)</td>
            <td>Address</td>
            <td class="textarea">Comment</td>
			<td>Delete</td>
		</tr>
		<?php
		while($res = mysqli_fetch_array($result)) {		
			echo "<tr>";
            echo "<td>".$res['id']."</td>";
			echo "<td>".$res['name']."</td>";
			echo "<td>".$res['user']."</td>";
			echo "<td>".$res['pass']."</td>";
            echo "<td>" .$res['router']."</td>";
            echo "<td>".$res['price']."</td>";
            echo "<td>".$res['address']."</td>";
            echo "<td>".$res['comment']."</td>";
			echo "<td><br/> <br><a class='home1' href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
		}
		?>
	</table>
    <style>
        *{
            margin:0;
            padding: 0;
            font-family: sans-serif;
            font-size: auto;
        }
        body{
            background: #f2f2f2;
            height: 100vh;
            width: 100vw;
            margin-top: 30px;
            margin-left:20px;


        }
        .home{
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #4CAF50;
        }
        .home:hover{
            background-color: #003361;
            color: white;
        }
        .home1{
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 5px;
            border-radius: 5px;
            border: 1px solid #4CAF50;
        }
        .home1:hover{
            background-color: #003361;
            color: white;
        }
        .table {
            width: 100%;
            border: 2px solid #4CAF50;
            border-radius: 15px;
            text-align: center;
        }
        .tr{
          
            color: #4CAF50;
            border-radius: 15px;
            
        }
        .tr td{
            padding: 10px;

        }
        td {
            padding:10px
        }

        .search-box{
        width: 300px;
        position: relative;
        display: inline-block;
        font-size: 14px;
    }
    .search-box input[type="text"]{
        height: 32px;
        padding: 5px 10px;
        border: 1px solid #4CAF50;
        border-radius:20px;
        font-size: 14px;
    }
    .result{
        position: absolute;        
        z-index: 999;
        top: 100%;
        left: 0;
    }
    .search-box input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result p:hover{
        background: #f2f2f2;
    }
       


    </style>	
</body>
</html>
