<html>
<head>
	<title>Register-websurfer Client</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<a class="home" href="index.php">Home</a> <br />
<?php
include("connection.php");

if(isset($_POST['submit'])) {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$user = $_POST['username'];
	$pass = $_POST['password'];

	if($user == "" || $pass == "" || $name == "" || $email == "") {
		echo "All fields should be filled. Either one or many fields are empty.";
		echo "<br/>";
		echo "<a href='register.php'>Go back</a>";
	} else {
		mysqli_query($mysqli, "INSERT INTO login(name, email, username, password) VALUES('$name', '$email', '$user', ('$pass'))")
			or die("Could not execute the insert query.");
			
		echo "Registration successfully";
		echo "<br/><br/>";
		echo "<a class='home' href='login.php'>Login</a>";
	}
} else {
?>
	<h2>Register Your Account</h2>
    <div class="table">
	<form name="form1" method="post" action="">
            <p>Full Name</p>
            <input type="text" name="name" placeholder="Enter Your Name">
            <p>Email</p>
            <input type="email" name="email" placeholder="Enter Your Email">
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Your Username">
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Your Password"><br></br>
            <input type="submit" name="submit" value="Register">
</div>
	</form>
    <style>
        
    </style>
<?php
}
?>
</body>
</html>
