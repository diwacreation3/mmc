<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	
	$name = $_POST['name'];
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	$router= $_POST['router'];
	$price = $_POST['price'];
	$address = $_POST['address'];
	$comment = $_POST['comment'];	
	
	// checking empty fields
	if(empty($name) || empty($user) || empty($pass) || empty($router) || empty($price) || empty($address) || empty($comment)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($user)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($pass)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
		if(empty($router)){
			echo "<font color='red'>Router field is empty.</font><br/>";
		}
		if(empty($price)){
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
		if(empty($address)){
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($comment)){
			echo "<font color='red'>Address field is empty.</font><br/>";
		}

	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE users SET name='$name', user='$user', pass='$pass', router='$router',price'$price',address'$address',comment'$comment' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is view.php
		header("Location: view.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$user = $res['user'];
	$pass = $res['pass'];
    $router= $res['router'];
    $price = $res['price'];
    $address = $res['address'];
    $comment = $res['comment'];
}
?>

<html>
<head>	
	<title>Edit User Data</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>
<a class="home" href="index.php">Home</a> <a class="home" href="view.php">View Users</a> <a class="home" href="logout.php">Logout</a>
    <h2>update users Data</h2>

    <div class="table">
        <form action="edit.php" name="form1" method="post">
            <p>
                <input type="text" name="name" value="<?php echo $name;?>">
            </p>
            <p>
                <input type="text" name="user" value="<?php echo $user;?>">
            </p>
            <p>
                <input type="password" name="pass" value="<?php echo $pass;?>">
            </p>
            <p>
                <input type="text" name="router" value="<?php echo $router;?>">
            </p>
            <p>
                <input type="text" name="price" value="<?php echo $price;?>">
            </p>
            <p>
                <input type="text" name="address" value="<?php echo $address;?>">
            </p>
            <p>
                <input type="text" name="comment" value="<?php echo $comment;?>">
            </p>
            <p>
				<input type="hidden" name ="id" value=<?php echo $_GET['id'];?>>
                <input type="submit" name="Update User" value="update">
            </p>

        </form>
		<style>

		</style>
    </div>
</body>
</html>
